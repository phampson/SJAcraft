# ECS160Android

[Project summary under construction]

## What's New
* Made basic splash screen and main menu with background music 
* Background music pauses when exiting out of app or on pauses, resumes if returning to app

## Screenshots
|Splash Screen|Main Menu|
|---|---|
|<img src="/screenshots/Screenshot_20171007-223524.png" width="250px" height="auto">|<img src="/screenshots/Screenshot_20171008-200030.png" width="auto" height="240px">|
