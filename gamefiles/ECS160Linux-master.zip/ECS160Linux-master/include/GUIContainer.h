/*
    Copyright (c) 2015, Christopher Nitta
    All rights reserved.

    All source material (source code, images, sounds, etc.) have been provided to
    University of California, Davis students of course ECS 160 for educational
    purposes. It may not be distributed beyond those enrolled in the course without
    prior permission from the copyright holder.

    All sound files, sound fonts, midi files, and images that have been included 
    that were extracted from original Warcraft II by Blizzard Entertainment 
    were found freely available via internet sources and have been labeld as 
    abandonware. They have been included in this distribution for educational 
    purposes only and this copyright notice does not attempt to claim any 
    ownership of this material.
*/
#ifndef GUICONTAINER_H
#define GUICONTAINER_H
#include "GUIWidget.h"

class CGUIContainer : public virtual CGUIWidget{
    public:
        virtual ~CGUIContainer(){};
        
        virtual void SetBorderWidth(int width) = 0;
        virtual void Add(std::shared_ptr<CGUIWidget> widget) = 0;
        virtual void Remove(std::shared_ptr<CGUIWidget> widget) = 0;
};

#endif

