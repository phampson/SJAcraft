This is a placeholder file for the AI team. 
Unable to commit blank folders to git.

Contact: Chris Ta, cta@ucdavis.edu
