//
//  AppDelegate.swift
//  WarCraft2
//
//  Created by Yepu Xie on 10/4/17.
//  Copyright © 2017 UC Davis. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {

    func applicationDidFinishLaunching(_: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_: Notification) {
        // Insert code here to tear down your application
    }
}
