export interface Coordinate {
  x: number;
  y: number;
}
