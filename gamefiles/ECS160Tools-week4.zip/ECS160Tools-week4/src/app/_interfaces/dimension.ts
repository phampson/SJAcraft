export interface Dimension {
  width: number;
  height: number;
}
