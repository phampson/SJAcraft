import { Coordinate } from './coordinate';
import { Dimension } from './dimension';

export interface Region extends Dimension, Coordinate {
}
