//
//  AssetDecoratedMap.swift
//  Warcraft2v1
//
//  Created by Hong Truong on 10/24/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//

import Foundation

// FIXME: Stop hardcoding
let LINE_WITH_RESOURCE_COUNT = 78
let LINE_WITH_ASSET_COUNT = 86

class CAssetDecoratedMap : CTerrainMap
{
    struct SResourceInitialization
    {
        var DColor: EPlayerColor
        var DGold: Int
        var DLumber: Int
        
        init()
        {
            DColor = EPlayerColor.None
            DGold = 0
            DLumber = 0
        }
    }
    
    struct SAssetInitialization
    {
        var DType: String
        var DColor: EPlayerColor
        var DPos: CPosition // TODO: Change to DTilePosition
        
        init()
        {
            DType = "None"
            DColor = EPlayerColor.None
            DPos = CPosition()
        }
    }
    
    var DFilename: String
    var DResourceInitializationList: [SResourceInitialization]
    var DAssetInitializationList: [SAssetInitialization]
    
    var DMapNameTranslation: [String: Int]!
    var DAllMaps: [CAssetDecoratedMap]!
    
    override init(filename: String)
    {
        DResourceInitializationList = [SResourceInitialization]()
        DAssetInitializationList = [SAssetInitialization]()
        DFilename = filename
        super.init(filename: DFilename)
    }
    
    /// Fill the asset initialization list with the data from the map file
    ///
    /// - Author: Hong 10/29
    /// - TODO: Add edge cases from cpp file (ignored when porting)
    /// - Returns: True if map data was loaded; otherwise false
    func LoadMap()
    {
        let MapData = CDataSource.Load(fileName: DFilename, extensionType: "map", commentChar: "#")
        
        // Get the initial resource data
//        let LineWithNumResources = LINE_WITH_MAP_STRING + MapHeight + 1 + MapHeight + 1
        let ResourceCount = Int(MapData[LINE_WITH_RESOURCE_COUNT])!
        var TempResourceInit = SResourceInitialization()
        
        for Index in 0...ResourceCount
        {
            // Skip the comment line
            let Tokens = MapData[LINE_WITH_RESOURCE_COUNT + 2 + Index].components(separatedBy: " ")
            
            TempResourceInit.DColor = EPlayerColor(rawValue: Int(Tokens[0])!)!
            TempResourceInit.DGold = Int(Tokens[1])!
            TempResourceInit.DLumber = Int(Tokens[2])!
            
            self.DResourceInitializationList.append(TempResourceInit)
        }
        
        
        // Get the initial asset data
//        let LineWithNumAssets = LineWithNumResources + ResourceCount + 4
        let AssetCount = Int(MapData[LINE_WITH_ASSET_COUNT])!
        
        for Index in 0..<AssetCount
        {
            var TempAssetInit = SAssetInitialization()
            let Tokens = MapData[LINE_WITH_ASSET_COUNT + 2 + Index].components(separatedBy: " ")
            TempAssetInit.DType = Tokens[0]
            TempAssetInit.DColor = EPlayerColor(rawValue: Int(Tokens[1])!)!
            TempAssetInit.DPos.DX = Int(Tokens[2])!
            TempAssetInit.DPos.DY = Int(Tokens[3])!
            
            DAssetInitializationList.append(TempAssetInit)
        }
        // TODO: Add lumber stuff
    }
    
    func LoadMaps() {
        let TempMap1 = CAssetDecoratedMap(filename: "bay")
        TempMap1.LoadMap()
        TempMap1.RenderTerrain()
        DMapNameTranslation["bay"] = DAllMaps.count
        DAllMaps.append(TempMap1)
        let TempMap2 = CAssetDecoratedMap(filename: "hedges")
        TempMap2.LoadMap()
        TempMap2.RenderTerrain()
        DMapNameTranslation["hedges"] = DAllMaps.count
        DAllMaps.append(TempMap2)
        let TempMap3 = CAssetDecoratedMap(filename: "mountain")
        TempMap3.LoadMap()
        TempMap3.RenderTerrain()
        DMapNameTranslation["mountain"] = DAllMaps.count
        DAllMaps.append(TempMap3)
        let TempMap4 = CAssetDecoratedMap(filename: "nwhr2rn")
        TempMap4.LoadMap()
        TempMap4.RenderTerrain()
        DMapNameTranslation["nwhr2rn"] = DAllMaps.count
        DAllMaps.append(TempMap4)
    }
    
    
}
