//
//  AssetRenderer.swift
//  Warcraft2v1
//
//  Created by Hong Truong on 10/24/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//

import Foundation
import SpriteKit

class CAssetRenderer
{
    // TODO: Fill with the rest of the data
    struct SAssetRenderData
    {
        var DType: EAssetType
        var DX: Int
        var DY: Int
        var DTileIndex: Int
        
        init()
        {
            DType = EAssetType.None
            DX = 0
            DY = 0
            DTileIndex = 0
        }
    }
    
    var DPlayerMap: CAssetDecoratedMap
    var DTilesets: [CGraphicTileset]
    
    init(tilesets: [CGraphicTileset], map: CAssetDecoratedMap)
    {
        DTilesets = tilesets
        DPlayerMap = map
    }
    
    func DrawAssets(surface: SKTileMapNode)
    {
        // TODO: Change to use the general Asset list
        for Asset in DPlayerMap.DAssetInitializationList
        {
//            TempRenderData.DType = Asset.DType
            var TempRenderData = SAssetRenderData()
            TempRenderData.DType = StringToAsset(stringType: Asset.DType)
            if EAssetType.None == TempRenderData.DType
            {
                continue
            }
            
            TempRenderData.DX = Asset.DPos.DX
            TempRenderData.DY = Asset.DPos.DY
            
            // TODO: Figure out what DTileIndex is
            // It's version of that asset's image (e.g. Peasant[0] -> Peasant[1])?
            TempRenderData.DTileIndex = 0
            
            DTilesets[TempRenderData.DType.rawValue].DrawTile(surface: surface, x: TempRenderData.DX, y: TempRenderData.DY, tileIndex: TempRenderData.DTileIndex)
        }
    }
    
    // TODO: Figure out how this class actually converts the String in DAssetInitializationList to EAssetType
    func StringToAsset(stringType: String) -> EAssetType
    {
        switch stringType
        {
        case "None"         : return EAssetType.None
        case "Peasant"      : return EAssetType.Peasant
        case "Footman"      : return EAssetType.Footman
        case "Archer"       : return EAssetType.Archer
        case "Ranger"       : return EAssetType.Ranger
        case "GoldMine"     : return EAssetType.GoldMine
        case "TownHall"     : return EAssetType.TownHall
        case "Keep"         : return EAssetType.Keep
        case "Castle"       : return EAssetType.Castle
        case "Farm"         : return EAssetType.Farm
        case "Barracks"     : return EAssetType.Barracks
        case "LumberMill"   : return EAssetType.LumberMill
        case "Blacksmith"   : return EAssetType.Blacksmith
        case "ScoutTower"   : return EAssetType.ScoutTower
        case "GuardTower"   : return EAssetType.GuardTower
        case "CannonTower"  : return EAssetType.CannonTower
        case "Max"          : return EAssetType.Max
        default: return EAssetType.None
        }
    }
}
