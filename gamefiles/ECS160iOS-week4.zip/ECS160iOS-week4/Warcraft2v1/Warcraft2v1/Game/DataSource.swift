//
//  DataSource.swift
//  Warcraft2v1
//
//  Created by Hong Truong on 10/19/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//

import Foundation

class CDataSource{
    
    static var data = [String]()
    static var currentLine = 0
    static var commentChar = "\n\t\r"
    
    init(){
    }
    
    /// Read in files and parse lines with new line
    ///
    /// - Author: Patty 10/20
    /// - Parameters:
    ///     - fileName: The file that needs to be opened and read in
    ///     - extensionType: They type of the data file
    ///     - commentChar: Character that signifies a line in a file is a comment; to be skipped
    /// - Returns: An array of strings
    static func Load(fileName: String, extensionType: String, commentChar: String) -> [String]{
        
        let dir = FindDirectory(extensionType: extensionType)
        let path = Bundle.main.url(forResource: fileName, withExtension: extensionType, subdirectory: dir)!
        
        do
        {
            let readStringProject = try String(contentsOf: path)
            data = readStringProject.components(separatedBy: .newlines)
        }
        catch
        {
            print("Error")
        }
        currentLine = 0
        self.commentChar = commentChar
        return data
    }
    
    /// Reads a single line from a file. Skips any lines containing a comment
    ///
    /// - Parameter file: Contains the data from a file
    /// - Returns: The current line
    static func Read(from file: [String]) -> String
    {
        while data[currentLine].contains(Character(commentChar))
        {
            currentLine += 1
        }
        let line = data[currentLine]
        currentLine += 1 // Next time this file is read, it'll read a new line
        return line
    }
    
    private static func FindDirectory(extensionType: String) -> String
    {
        var directory: String
        
        switch extensionType
        {
        case "dat": directory = "img"
        case "map": directory = "map"
        default: directory = ""
        }
        return directory
    }
    
    static func LineNumber(fileData: [String], startLineNumber: Int ) -> Int
    {
        var currentLineNumber: Int = startLineNumber
        while fileData[currentLineNumber].characters.contains("#") == false
        {
            
            currentLineNumber = currentLineNumber + 1
        }
        return currentLineNumber
    }
}
