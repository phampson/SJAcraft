//
//  GameViewController.swift
//  Warcraft2v1
//
//  Created by King on 10/12/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit
import AVFoundation

class GameViewController : UIViewController
{
    //Audio Variables
    var  game1Player:AVAudioPlayer!
    override func viewDidLoad()
    {
        
        super.viewDidLoad()
        /// Convert view from UIView to SKView
        if let view = self.view as! SKView?
        {
            playSound(file: "game1")
            
            /// Load GameScene into this view
            if let scene = SKScene(fileNamed: "GameScene")
            {
                scene.size = CGSize(width: 600, height:600)
                scene.scaleMode = .resizeFill
                //view.contentMode = UIViewContentMode.scaleAspectFill
                scene.anchorPoint = CGPoint(x: 0, y: 0)
//                scene.yScale = -1
                view.presentScene(scene)
            }
            
            view.ignoresSiblingOrder = true
        }
    }
}

