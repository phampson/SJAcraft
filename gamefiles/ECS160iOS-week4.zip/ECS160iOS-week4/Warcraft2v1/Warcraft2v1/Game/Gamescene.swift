//
//  GameScene.swift
//  Warcraft2v1
//
//  Created by Hong Truong on 10/13/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//
let BUFFER: CGFloat = 10

import Foundation
import UIKit
import SpriteKit
import AVFoundation

let MAP_NAME = "nwhr2rn"

class Gamescene: SKScene //
{
    var skNode = SKSpriteNode()
    var mmNode = SKSpriteNode()

    var peasantMap = Peasant()
    var peasant = Peasant()
    var mmWidth = 32
    var mmHeight = 32
    var cam =  SKCameraNode()
    var hudMade = false
    var gSqr = SKShapeNode(rectOf: CGSize(width: 148, height: 414))
    
    var DMapRenderer: CMapRenderer!
    var DAssetRenderer: CAssetRenderer!
    var DTerrainTilesets: CGraphicTileset!
    var DAssetTilesets: [CGraphicTileset] = []

    
    override func didMove(to view: SKView)
    {
        super.didMove(to: view)
        Activate()
        LoadGameMap(map: MAP_NAME)
        
        if !hudMade
        {
            setupHud(cam: cam)
            hudMade = true
        }
        
        
    }
    
    func Test(surface: SKTileMapNode)
    {
        surface.anchorPoint = CGPoint(x: 0, y: 0)
        let GoldMine = CGraphicTileset()
        GoldMine.LoadTileset(from: "GoldMine")
        let sprite = SKSpriteNode(texture: GoldMine.tileTextures[0])
        sprite.position = CGPoint(x: 0, y: 29*32)
        sprite.anchorPoint = CGPoint(x: 0, y: 0)
        surface.addChild(sprite)
    }
    
    /// Load all files before runtime
    func Activate()
    {
        // Load maps
        
        
        // Load Terrain
        DTerrainTilesets = CGraphicTileset()
        DTerrainTilesets.LoadTileset(from: "Terrain")
        
        // Load Assets
//        DAssetTilesets = Array(repeating: nil, count: EAssetType.Max.rawValue)
        DAssetTilesets.reserveCapacity(EAssetType.Max.rawValue)
        for _ in 0..<EAssetType.Max.rawValue
        {
            DAssetTilesets.append(CGraphicTileset())
        }
        
        DAssetTilesets[EAssetType.Peasant.rawValue].LoadTileset(from: "Peasant")
        DAssetTilesets[EAssetType.Footman.rawValue].LoadTileset(from: "Footman")
        DAssetTilesets[EAssetType.Archer.rawValue].LoadTileset(from: "Archer")
        DAssetTilesets[EAssetType.Ranger.rawValue].LoadTileset(from: "Ranger")
        DAssetTilesets[EAssetType.GoldMine.rawValue].LoadTileset(from: "GoldMine")
        DAssetTilesets[EAssetType.TownHall.rawValue].LoadTileset(from: "TownHall")
        DAssetTilesets[EAssetType.Keep.rawValue].LoadTileset(from: "Keep")
        DAssetTilesets[EAssetType.Castle.rawValue].LoadTileset(from: "Castle")
        DAssetTilesets[EAssetType.Farm.rawValue].LoadTileset(from: "Farm")
        DAssetTilesets[EAssetType.Barracks.rawValue].LoadTileset(from: "Barracks")
        DAssetTilesets[EAssetType.LumberMill.rawValue].LoadTileset(from: "LumberMill")
        DAssetTilesets[EAssetType.Blacksmith.rawValue].LoadTileset(from: "Blacksmith")
        DAssetTilesets[EAssetType.ScoutTower.rawValue].LoadTileset(from: "ScoutTower")
        DAssetTilesets[EAssetType.GuardTower.rawValue].LoadTileset(from: "GuardTower")
        DAssetTilesets[EAssetType.CannonTower.rawValue].LoadTileset(from: "CannonTower")
    }
    
    func LoadGameMap(map: String)
    {
        // Setup the renderers
        DMapRenderer = CMapRenderer(mapFile: map)
        
        let AssetMap = CAssetDecoratedMap(filename: map)
        AssetMap.LoadMap()
        DAssetRenderer = CAssetRenderer(tilesets: DAssetTilesets, map: AssetMap)
//        DMiniMapRenderer = CMiniMapRenderer
        
        // Create the map
        let skTileMapNode = DMapRenderer.DrawMap(surface: self, tiles: DTerrainTilesets)
        skTileMapNode.anchorPoint = CGPoint(x: 0, y: 0)
//        Test(surface: skTileMapNode)
        
        DAssetRenderer.DrawAssets(surface: skTileMapNode)
        
        setupCamera(on: skTileMapNode)
        
        //display the mini map
        let mmImg = DMapRenderer.DrawMiniMap(width: 33, height: 33)
        mmNode = SKSpriteNode(texture: SKTexture(image: mmImg))
        mmNode.anchorPoint = CGPoint(x: 0, y: 0)
        mmNode.position = CGPoint(x: 0, y: 0)
        mmNode.zPosition = 101
        camera!.addChild(mmNode)
        peasantMap.player.position = CGPoint(x: 20, y: -100)
        peasantMap.player.setScale(0.2)
        peasantMap.player.zPosition = 200
        mmNode.addChild(peasantMap.player)
        
    }
    
    // FIXME: Camera goes off map at bottom
    func setupCamera(on map: SKTileMapNode)
    {
        // Install the camera
        cam = self.childNode(withName: "camera") as! SKCameraNode
        
        // Constrain the camera within the map region
        let Xlimit = (map.mapSize.width - self.size.width)/2
        let Ylimit = (map.mapSize.height - (self.size.height))/2 //FIX ME: the logic applied to Xlimit doesnt work with Ylimit
        
        let rangeX = SKRange(lowerLimit: -Xlimit - 150,upperLimit: Xlimit)
        let rangeY = SKRange(lowerLimit: -Ylimit,upperLimit: Ylimit)
//        let lockToX = SKConstraint.positionX(rangeX)
//        let lockToY = SKConstraint.positionY(rangeY)
//        cam.constraints = [ lockToX,lockToY ]
        
        // Peasant stuff
        peasant.player.zPosition = 50
        peasant.player.position = CGPoint(x: 218,y: 218)
        map.addChild(peasant.player)
        

        
        // Make screen smaller for testing
//        cam.xScale = 3
//        cam.yScale = 3
    }
    
    ///Author: Dylon, Andy 10/28
    ///Displays the Heads Up Display and Mini map
    func setupHud(cam: SKCameraNode) {
        //display the side panel
        gSqr.name = "square"
        gSqr.fillColor = .brown
        gSqr.strokeColor = .black
        gSqr.lineWidth = 1
        gSqr.accessibilityElementsHidden = false
        gSqr.position = CGPoint(x: cam.frame.size.width/2, y: cam.frame.size.height/2)
        
        //print("height: \(cam.frame.size.height)")
        
        gSqr.alpha = 1.0
        gSqr.zPosition = 100
        cam.addChild(gSqr)
    }
    
    override func didSimulatePhysics ()
    {
        gSqr.position = camera!.position
        
        gSqr.position = CGPoint(
            x: -(size.width / 2) + (gSqr.frame.size.width / 2),
            y: 0
        )
        mmNode.position = camera!.position
        
        mmNode.anchorPoint = CGPoint(x: 0, y: 1)
        mmNode.position = CGPoint(
            x: -(size.width / 2) + BUFFER,
            y: (size.height / 2) - BUFFER
        )
    }
    
    
    
    /// -Authors: Andy 10/15
    /// Function: Move "skNode" which loads map based on location of touch
    
    ///FIXME: This moves the SKTSprite Node. Technically not the map???
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        /*for touch in touches
         {
         let location = touch.location(in: self)
         skNode.position = CGPoint(x: location.x, y: location.y)
         }*/
        
        for touch in touches {
            //if touches.count == 2 { // Two finger swipe for map panning
                let location = touch.location(in: self)
                let previousLocation = touch.previousLocation(in: self)
                let deltaY = previousLocation.y - location.y
                let deltaX = previousLocation.x - location.x
                cam.position.y += deltaY
                cam.position.x += deltaX
            //}
            
            if(peasant.isSelected){
                peasant.moveToPosition(fPosition: touches.first!.location(in:self))
            }
            else {
                if let name = self.atPoint(touches.first!.location(in:self)).name{
                    if name == peasant.player.name {
                        playWav(file: "acknowledge1", dir: "snd/peasant")
                            peasant.selected()
                    }
                }
            }
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if(peasant.isSelected){
            playWav(file: "acknowledge1", dir: "snd/peasant")
            //if(point.x > (cam.position.x - 100)){ //If selects the map, moves
            peasant.moveToPosition(fPosition: touches.first!.location(in:self))
            var newpos = touches.first!.location(in:self)
            newpos.x = (newpos.x * 0.1) + 20
            newpos.y = (newpos.y * 0.1) - 100
            
            peasantMap.moveToPosition(fPosition: newpos )
            //}
            //else{ //Otherwise, it selected the minimap or other part of the screen
            //peasant.unSelected()
            //}
        }
        else {
            if let name = self.atPoint(touches.first!.location(in:self)).name{
                if name == peasant.player.name {
                    peasant.selected()
                }
            }
        }
        
    }
}

