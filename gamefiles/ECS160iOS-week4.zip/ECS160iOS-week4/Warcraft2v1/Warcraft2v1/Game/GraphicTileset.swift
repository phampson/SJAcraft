//
//  GraphicTileset
//  Warcraft2v1
//
//  Created by Hong Truong on 10/19/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//

import Foundation
import UIKit
import SpriteKit

let TERRAIN_TILE_SIZE = 32

class CGraphicTileset {
//    var tileSet: SKTileSet?
//    var tileGroups = [SKTileGroup]()
    var tileTextures: [SKTexture]!
    
    var DMapping: [String : Int] = [:]
    var DTileNames: [String]!
    var DGroupNames: [String]!
    var DGroupSteps: [String : Int]!
    var DTileCount: Int
    var DTileWidth: Int
    var DTileHeight: Int
    var DTileHalfWidth: Int
    var DTileHalfHeight: Int
    
    init(){
        tileTextures = [SKTexture]()
        DTileCount = 0;
        DTileWidth = 0;
        DTileHeight = 0;
        DTileHalfWidth = 0;
        DTileHalfHeight = 0;
    }
    
    /// Gets tileset information from its .dat file and creates SKTextures
    /// from the images. Information includes:
    ///
    /// - Path to its PNG file
    /// - Number of tiles
    /// - Name of each tile in the tileset
    ///
    /// - Author: Hong 10/29
    /// - Parameter filename: Name of the tileset to load data from
    func LoadTileset(from filename: String)
    {
        let file = CDataSource.Load(fileName: filename, extensionType: "dat", commentChar: "#")
        _ = CDataSource.Read(from: file)
        
        // Get the tile count and names and store them
        DTileCount = Int(CDataSource.Read(from: file))!
        DTileNames = Array(repeating: "", count: DTileCount)
        
        var TempString: String
        for Index in 0..<DTileCount
        {
            TempString = CDataSource.Read(from: file)
            DTileNames[Index] = TempString
            DMapping[TempString] = Index
        }
        
        // Split the image into individual tile images
        let tileImages = splitImageIntoTiles(image: UIImage(named: filename)!, numTiles: DTileCount)!
        
        // Get the tile size
        DTileWidth = Int(tileImages[0].size.width)
        DTileHeight = Int(tileImages[0].size.height)
        
        // Create the tilegroup and tileset
        for tile in tileImages
        {
            tileTextures.append(SKTexture(image: tile))
        }
    }
    
    /// Creates SKTileGroup and SKTileset files for the SKTileMapNode
    ///
    /// - Returns: Tuple of the array of SKTileGroups and the SKTileset made from those groups
    func CreateSKTiles() -> ([SKTileGroup], SKTileSet)
    {
        var tileGroups = [SKTileGroup]()
        for Index in 0..<tileTextures.count
        {
            tileGroups.append(SKTileGroup(tileDefinition: SKTileDefinition(texture: tileTextures[Index])))
        }
        let tileSet = SKTileSet(tileGroups: tileGroups)
        
        return (tileGroups, tileSet)
    }
    
    /// Displays the tileIndex version of the tile on (x,y) of the surface
    ///
    /// - Author: Hong 10/29
    ///
    /// - Parameters:
    ///   - surface: Surface on which the tile will be displayed
    ///   - x: X position of where tile will be displayed
    ///   - y: Y position of where tile will be displayd
    ///   - tileIndex: The type/variation of this tile that will be displayed
    func DrawTile(surface: SKTileMapNode, x: Int, y: Int, tileIndex: Int)
    {
        let sprite = SKSpriteNode(texture: tileTextures[tileIndex])
        sprite.position = CGPoint(x: x * (TERRAIN_TILE_SIZE - 2), y: y * (TERRAIN_TILE_SIZE - 2))

        sprite.anchorPoint = CGPoint(x: 0 , y: 0)
        surface.addChild(sprite)
    }
    
    /// Splits an image into an array of tiles
    ///
    /// - Authors: Hong Patty Yunwon 10/12
    ///
    /// - Parameters:
    ///   - image: The original image or tile sheet
    ///   - tileSize: The length or width of the tile (square)
    /// - Returns: An array of tiles
//    func splitImageIntoTiles(image: UIImage, tileSize: Int) -> [UIImage]?
    func splitImageIntoTiles(image: UIImage, numTiles: Int) -> [UIImage]!
    {
        let height = Int(image.size.height) / numTiles
        let width = Int(image.size.width)
        
        let hCount = Int(image.size.height) / height
        let wCount = Int(image.size.width) / width
        
        var tiles:[UIImage] = []
        
        for i in 0..<hCount
        {
            for p in 0..<wCount
            {
                let rect = CGRect(x: p * height, y: i * width, width: width, height: height)
                let temp:CGImage = image.cgImage!.cropping(to: rect)!
                tiles.append(UIImage(cgImage: temp))
            }
        }
        return tiles
    }
}


