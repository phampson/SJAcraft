//
//  MapRenderer.swift
//  Warcraft2v1
//
//  Created by Hong Truong on 10/28/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//

import Foundation
import SpriteKit

let LINE_WITH_NUM_TILES = 3
let TILE_SIZE = 32

class CMapRenderer
{
    let DMap: CTerrainMap
    var DTileIndices:[[[Int]]] = []
    
    init(mapFile: String)
    {
        // Create a 2D map of the tile indices
        DMap = CTerrainMap(filename: mapFile)
        DMap.RenderTerrain()
    
        // Get the names of each tile
        var lines = CDataSource.Load(fileName: "Terrain", extensionType: "dat", commentChar: "#")
 
        let numTiles = Int(lines[LINE_WITH_NUM_TILES])!
        DTileIndices = Array(repeating: Array(repeating: Array(repeating: 0, count: 0), count: 16), count: 11)

        // Convert the tile name into hexadecimals and store them in the position they belong
        for i in LINE_WITH_MAP_STRING...numTiles+4{ // through .dat file
            let ans = ParseLine(line: lines[i])
            DTileIndices[ans[0]][ans[1]].append(i - 5);
        }
    }

    func DrawMap(surface: SKScene, tiles: CGraphicTileset) -> SKTileMapNode
    {
        let width = DMap.MapWidth
        let height = DMap.MapHeight
        var tileGroups: [SKTileGroup]
        var tileSet: SKTileSet
        
        (tileGroups, tileSet) = tiles.CreateSKTiles()
        let tileSize = CGSize(width: TILE_SIZE, height: TILE_SIZE)
     
        // Create a blank map node with the same dimensions as the terrain map
        let mapNode = SKTileMapNode(tileSet: tileSet, columns: width, rows: height, tileSize: tileSize)
        
        
        // Convert each tile index into a tile and store it in the map node
        var DisplayIndex = 0
        for i in 0...height-1
        {
            for j in 0...width-1 // column by column
            {
                let ThisTileType = DMap.TileType(x: j, y: i)
                let TileIndex = DMap.TileTypeIndex(x: j, y: i)
                
                // Total number of variations for a tile of ThisTileType and TileIndex
                let AltTileCount = DTileIndices[ThisTileType.rawValue][TileIndex].count
                
                // Randomly choose a tile variation
                if(AltTileCount != 0){
                    let AltIndex = (i + j) % AltTileCount;
                    DisplayIndex = DTileIndices[ThisTileType.rawValue][TileIndex][AltIndex]
                }
                
                // Assign the correct tile group to the specified position
                // NOTE: Swift sees increasing y as going up and increasing x as going right
                mapNode.setTileGroup(tileGroups[DisplayIndex], forColumn: j, row: mapNode.numberOfRows-i)
            }
        }
        surface.addChild(mapNode)
        return mapNode
    }
    
    ///Author: Dylon 10/28
    ///Given the dimensions of the actual map, draws the mini map onto a UIImage and returns the image
    public func DrawMiniMap(width:Int, height:Int)->UIImage {
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        let bitmapInfo: CGBitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedFirst.rawValue)
        let bitsPerComponent:Int = 8
        let bitsPerPixel:Int = 32
        
        assert(DMap.miniMap.count == Int(width * height))
        
        var data = DMap.miniMap
        let dataRef = CGDataProvider(
            data: NSData(bytes: &data, length: data.count * MemoryLayout<pixel>.size)
        )
        
        let cgim = CGImage(
            width: (width - 1),
            height: (width - 1),
            bitsPerComponent: bitsPerComponent,
            bitsPerPixel: bitsPerPixel,
            bytesPerRow: (width - 1) * Int(MemoryLayout<pixel>.size),
            space: rgbColorSpace,
            bitmapInfo: bitmapInfo,
            provider: dataRef!,
            decode: nil,
            shouldInterpolate: true,
            intent: .defaultIntent
        )
        UIGraphicsBeginImageContext(CGSize(width: 128, height: 128))
        UIImage(cgImage: cgim!).draw(in: CGRect(x: 0, y: 0,width: 128,height: 128))
        let scaledImg = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return scaledImg!
    }
    
    /// Convert a tile name of form "type-form-variation"
    /// - type: The type of tile (e.g. grass, dirt, etc). Different types cannot mix
    /// - form: The style of the tyle. Different forms cannot mix
    /// - variation: A variation of each type's form. Can mix variations
    ///
    /// - Parameter line: Tile name
    /// - Returns: Array containing the tile's type, form, and variation as a
    ///     hexadecimal from 0 to F
    func ParseLine(line: String) -> [Int]{
        var ans = [0, 0, 0]
        
        // Separate the tile's name into its separate type, form, and variation
        var tokens = line.components(separatedBy: "-")
        
        // Convert the type
        if (tokens[0] == "dark" && tokens[1] == "grass") {ans[0] = 1}
        else if (tokens[0] == "light" && tokens[1] == "grass") {ans[0] = 2}
        else if (tokens[0] == "dark" && tokens[1] == "dirt") {ans[0] = 3}
        else if (tokens[0] == "light" && tokens[1] == "dirt") {ans[0] = 4}
        else if (tokens[0] == "rock") {ans[0] = 5}
        else if (tokens[0] == "rubble") {ans[0] = 6}
        else if (tokens[0] == "forest") {ans[0] = 7}
        else if (tokens[0] == "stump") {ans[0] = 8}
        else if (tokens[0] == "deep") {ans[0] = 9}
        else if (tokens[0] == "shallow") {ans[0] = 10}
        
        // Convert the form and variation
        if (tokens.count == 3){
            if let value = UInt8(tokens[1], radix: 16){
                ans[1] = Int(value)
            }
            ans[2] = Int(tokens[2])!
        }
        else if (tokens.count == 4){
            if let value = UInt8(tokens[2], radix: 16){
                ans[1] = Int(value)
            }
            ans[2] = Int(tokens[3])!
        }
        return ans
    }

}
