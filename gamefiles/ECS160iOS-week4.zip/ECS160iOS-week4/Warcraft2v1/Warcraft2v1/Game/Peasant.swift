//
//  Peasant.swift
//  SK
//
//  Created by Eden Bernabe on 10/27/17.
//  Copyright © 2017 TheWitzbold. All rights reserved.
//

import Foundation
import SpriteKit

// FIXME: Stop hardcoding
let NUM_TILES = 172

class Peasant{
  var player = SKSpriteNode(imageNamed: "Player")
  var isSelected: Bool
  
  var faceNorth = SKAction()
  var faceSouth = SKAction()
  var faceEast = SKAction()
  var faceWest = SKAction()
  
  var peasants: [UIImage]! = []
  
  init(){
    player.name = "player"
    self.isSelected = false
    player.zPosition = 0
    player.setScale(0.5)
    peasants = CGraphicTileset().splitImageIntoTiles(image: UIImage(named: "Peasant")!, numTiles: 172)
    
    player.texture = SKTexture(image: peasants[20])
    
    faceNorth = SKAction.setTexture(SKTexture(image: peasants[0]))
    faceSouth = SKAction.setTexture(SKTexture(image: peasants[20]))
    faceEast = SKAction.setTexture(SKTexture(image: peasants[10]))
    faceWest = SKAction.setTexture(SKTexture(image: peasants[30]))
  }
  
  func moveToPosition(fPosition: CGPoint){
    
    self.unSelected()
    var moveX:SKAction
    var moveY:SKAction
    var faceX:SKAction
    var faceY:SKAction
    
    var delta_x = fPosition.x - player.position.x
    if(delta_x < 0){
      delta_x = delta_x * -1
      moveX = SKAction.moveBy(x: delta_x, y:0, duration: TimeInterval(delta_x/100)).reversed()
      faceX = faceWest
    }
    else{
      moveX = SKAction.moveBy(x: delta_x, y:0, duration: TimeInterval(delta_x/100))
      faceX = faceEast
    }
    
    var delta_y = fPosition.y - player.position.y
    if(delta_y < 0){
      delta_y = delta_y * -1
      moveY = SKAction.moveBy(x: 0, y: delta_y, duration: TimeInterval(delta_x/100)).reversed()
      faceY = faceSouth
    }
    else{
      moveY = SKAction.moveBy(x: 0, y:delta_y, duration: TimeInterval(delta_x/100))
      faceY = faceNorth
    }
    
    let sequence = SKAction.sequence([faceX,moveX,faceY,moveY])
    player.run(sequence)
  }
  
  func selected(){
    player.texture = SKTexture(image: peasants[20] )
    player.colorBlendFactor = 0.6 //a way to make the border of the pic colored.
    self.isSelected = true;
  }
  
  func unSelected(){
    player.colorBlendFactor = 0.0
    self.isSelected = false
  }
}


