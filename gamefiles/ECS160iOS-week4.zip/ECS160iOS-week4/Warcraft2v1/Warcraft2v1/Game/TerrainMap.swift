//
//  Map.swift
//  Warcraft2v1
//
//  Created by Hong Truong on 10/19/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//

import Foundation

let LINE_WITH_MAP_NAME = 1
let LINE_WITH_MAP_DIMENSIONS = 3
let LINE_WITH_MAP_DESCRIPTION = 5
var LINE_WITH_MAP_STRING = 0


public struct pixel {
    var alpha: UInt8 = 255
    var red:   UInt8
    var green: UInt8
    var blue:  UInt8
}

// Ported by Stephen Wang 10/21
class CTerrainMap{
    
    enum ETerrainTileType: Int {
        case None
        case DarkGrass
        case LightGrass
        case DarkDirt
        case LightDirt
        case Rock
        case RockPartial
        case Forest
        case ForestPartial
        case DeepWater
        case ShallowWater
        case Max
    }
    
    enum ETileType: Int {
        case None
        case DarkGrass
        case LightGrass
        case DarkDirt
        case LightDirt
        case Rock
        case Rubble
        case Forest
        case Stump
        case DeepWater
        case ShallowWater
        case Max
    }
    
    static var DInvalidPartial = 0
    
    var DTerrainMap:[[ETerrainTileType]] = []
    var miniMap:[pixel] = []        //an array of structs containing each pixel's color data
    var DPartials:[[UInt8]] = []
    var DMap:[[ETileType]] = []
    var DMapIndices:[[Int]] = []
    var DMapName:String?
    var DMapTileset:String?
    var DMapDescription: [String] = []
    var MapWidth = 0
    var MapHeight = 0
    init(filename: String)
    {
        LoadMap(name: filename)
    }
    
    func CalculateTileTypeAndIndex(x: Int, y: Int, type: inout ETileType, index: inout Int){
        let UL = DTerrainMap[y][x]
        let UR = DTerrainMap[y][x+1]
        let LL = DTerrainMap[y+1][x]
        let LR = DTerrainMap[y+1][x+1]
        var TypeIndex = ((DPartials[y][x] & 0x8)>>3) | ((DPartials[y][x+1] & 0x4)>>1) | ((DPartials[y+1][x] & 0x2)<<1) | ((DPartials[y+1][x+1] & 0x1)<<3)
        
        if((ETerrainTileType.DarkGrass == UL)||(ETerrainTileType.DarkGrass == UR)||(ETerrainTileType.DarkGrass == LL)||(ETerrainTileType.DarkGrass == LR)){
            TypeIndex &= (ETerrainTileType.DarkGrass == UL) ? 0xF : 0xE;
            TypeIndex &= (ETerrainTileType.DarkGrass == UR) ? 0xF : 0xD;
            TypeIndex &= (ETerrainTileType.DarkGrass == LL) ? 0xF : 0xB;
            TypeIndex &= (ETerrainTileType.DarkGrass == LR) ? 0xF : 0x7;
            type = ETileType.DarkGrass
            index = Int(TypeIndex)
        }
        else if((ETerrainTileType.DarkDirt == UL)||(ETerrainTileType.DarkDirt == UR)||(ETerrainTileType.DarkDirt == LL)||(ETerrainTileType.DarkDirt == LR)){
            TypeIndex &= (ETerrainTileType.DarkDirt == UL) ? 0xF : 0xE;
            TypeIndex &= (ETerrainTileType.DarkDirt == UR) ? 0xF : 0xD;
            TypeIndex &= (ETerrainTileType.DarkDirt == LL) ? 0xF : 0xB;
            TypeIndex &= (ETerrainTileType.DarkDirt == LR) ? 0xF : 0x7;
            type = ETileType.DarkDirt;
            index = Int(TypeIndex);
        }
        else if((ETerrainTileType.DeepWater == UL)||(ETerrainTileType.DeepWater == UR)||(ETerrainTileType.DeepWater == LL)||(ETerrainTileType.DeepWater == LR)){
            TypeIndex &= (ETerrainTileType.DeepWater == UL) ? 0xF : 0xE;
            TypeIndex &= (ETerrainTileType.DeepWater == UR) ? 0xF : 0xD;
            TypeIndex &= (ETerrainTileType.DeepWater == LL) ? 0xF : 0xB;
            TypeIndex &= (ETerrainTileType.DeepWater == LR) ? 0xF : 0x7;
            type = ETileType.DeepWater;
            index = Int(TypeIndex);
        }
        else if((ETerrainTileType.ShallowWater == UL)||(ETerrainTileType.ShallowWater == UR)||(ETerrainTileType.ShallowWater == LL)||(ETerrainTileType.ShallowWater == LR)){
            TypeIndex &= (ETerrainTileType.ShallowWater == UL) ? 0xF : 0xE;
            TypeIndex &= (ETerrainTileType.ShallowWater == UR) ? 0xF : 0xD;
            TypeIndex &= (ETerrainTileType.ShallowWater == LL) ? 0xF : 0xB;
            TypeIndex &= (ETerrainTileType.ShallowWater == LR) ? 0xF : 0x7;
            type = ETileType.ShallowWater;
            index = Int(TypeIndex);
        }
        else if((ETerrainTileType.Rock == UL)||(ETerrainTileType.Rock == UR)||(ETerrainTileType.Rock == LL)||(ETerrainTileType.Rock == LR)){
            TypeIndex &= (ETerrainTileType.Rock == UL) ? 0xF : 0xE;
            TypeIndex &= (ETerrainTileType.Rock == UR) ? 0xF : 0xD;
            TypeIndex &= (ETerrainTileType.Rock == LL) ? 0xF : 0xB;
            TypeIndex &= (ETerrainTileType.Rock == LR) ? 0xF : 0x7;
            type = (TypeIndex != 0) ? ETileType.Rock : ETileType.Rubble;
            index = Int(TypeIndex);
        }
        else if((ETerrainTileType.Forest == UL)||(ETerrainTileType.Forest == UR)||(ETerrainTileType.Forest == LL)||(ETerrainTileType.Forest == LR)){
            TypeIndex &= (ETerrainTileType.Forest == UL) ? 0xF : 0xE;
            TypeIndex &= (ETerrainTileType.Forest == UR) ? 0xF : 0xD;
            TypeIndex &= (ETerrainTileType.Forest == LL) ? 0xF : 0xB;
            TypeIndex &= (ETerrainTileType.Forest == LR) ? 0xF : 0x7;
            if(Int(TypeIndex) != 0){
                type = ETileType.Forest;
                index = Int(TypeIndex);
            }
            else{
                type = ETileType.Stump;
                index = ((ETerrainTileType.Forest == UL) ? 0x1 : 0x0) | ((ETerrainTileType.Forest == UR) ? 0x2 : 0x0) | ((ETerrainTileType.Forest == LL) ? 0x4 : 0x0) | ((ETerrainTileType.Forest == LR) ? 0x8 : 0x0);
            }
            
        }
        else if((ETerrainTileType.LightDirt == UL)||(ETerrainTileType.LightDirt == UR)||(ETerrainTileType.LightDirt == LL)||(ETerrainTileType.LightDirt == LR)){
            TypeIndex &= (ETerrainTileType.LightDirt == UL) ? 0xF : 0xE;
            TypeIndex &= (ETerrainTileType.LightDirt == UR) ? 0xF : 0xD;
            TypeIndex &= (ETerrainTileType.LightDirt == LL) ? 0xF : 0xB;
            TypeIndex &= (ETerrainTileType.LightDirt == LR) ? 0xF : 0x7;
            type = ETileType.LightDirt;
            index = Int(TypeIndex);
            
        }
        else{
            // Error?
            type = ETileType.LightGrass;
            index = 0xF;
        }
    }

    /// Gets map data from a .map file. Data includes:
    /// - Map name
    /// - Map dimensions
    /// - String representation of the terrain map
    /// - String representation of the partial terrain map
    ///
    /// - Parameter name: Map filename
    func LoadMap(name: String){
        var lines = CDataSource.Load(fileName: name, extensionType: "map", commentChar: "#")
//        var lines = CDataSource().read(fileName: "nwhr2rn", extensionType: "map", Directory: "map")
        var tokens:[String]
        
        DMapName = lines[LINE_WITH_MAP_NAME]
        tokens = lines[LINE_WITH_MAP_DIMENSIONS].components(separatedBy: " ")
        MapWidth = Int(tokens[0])!
        MapHeight = Int(tokens[1])!
        DTerrainMap = Array(repeating: Array(repeating: ETerrainTileType.None, count: MapWidth+1), count: MapHeight+1)
        miniMap = Array(repeating: pixel(alpha: 0, red: 0, green: 0, blue: 0), count: (MapWidth+1)*(MapHeight+1))
        
        // Adding in Map Description
        var LineDescriptionEnd = CDataSource.LineNumber(fileData:lines, startLineNumber: LINE_WITH_MAP_DESCRIPTION)
        for index in LINE_WITH_MAP_DESCRIPTION ..< LineDescriptionEnd
        {
            DMapDescription.append(lines[index])
        }
        // Adding Map Tileset
        DMapTileset = lines[LineDescriptionEnd + 1]
        
        
        // line where map string starts
        var lineWithMapString = LineDescriptionEnd + 3
        LINE_WITH_MAP_STRING = lineWithMapString
        var StringMap:[String] = []
        for i in 0...MapHeight
        {
            StringMap.append(lines[i + lineWithMapString])
        }
        
        for index in 0...MapHeight
        {
            for j in 0...MapWidth
            {
                let str = StringMap[index]
                let inner = str.index(str.startIndex, offsetBy: j)
                
                switch StringMap[index][inner]
                {
                case "G":   DTerrainMap[index][j] = ETerrainTileType.DarkGrass
                            miniMap[index*MapWidth + j]     = SetMiniMapColors(colorCode: 0xFF144006)
                break;
                case "g":   DTerrainMap[index][j] = ETerrainTileType.LightGrass
                            miniMap[index*MapWidth + j]    = SetMiniMapColors(colorCode: 0xFF28540C)
                break;
                case "D":   DTerrainMap[index][j] = ETerrainTileType.DarkDirt
                            miniMap[index*MapWidth + j]    = SetMiniMapColors(colorCode: 0xFF3A2202)
                break;
                case "d":   DTerrainMap[index][j] = ETerrainTileType.LightDirt
                            miniMap[index*MapWidth + j]     = SetMiniMapColors(colorCode: 0xFF744404)
                break;
                case "R":   DTerrainMap[index][j] = ETerrainTileType.Rock
                            miniMap[index*MapWidth + j]     = SetMiniMapColors(colorCode: 0xFF424242)
                break;
                case "r":   DTerrainMap[index][j] = ETerrainTileType.RockPartial
                            miniMap[index*MapWidth + j]     = SetMiniMapColors(colorCode: 0xFF3A512B)
                break;
                case "F":   DTerrainMap[index][j] = ETerrainTileType.Forest
                            miniMap[index*MapWidth + j]     = SetMiniMapColors(colorCode: 0xFF002C00)
                break;
                case "f":   DTerrainMap[index][j] = ETerrainTileType.ForestPartial
                            miniMap[index*MapWidth + j]     = SetMiniMapColors(colorCode: 0xFF503000)
                break;
                case "W":   DTerrainMap[index][j] = ETerrainTileType.DeepWater
                            miniMap[index*MapWidth + j]     = SetMiniMapColors(colorCode: 0xFF051015)
                break;
                case "w":   DTerrainMap[index][j] = ETerrainTileType.ShallowWater
                            miniMap[index*MapWidth + j]     = SetMiniMapColors(colorCode: 0xFF0A1F2B)
                break;
                default: break;
                    
                }
            }
        }
        
        StringMap.removeAll()
        
        for i in 0...MapHeight
        {
            StringMap.append(lines[i + lineWithMapString + MapHeight + 2])
        }
        
        DPartials = Array(repeating: Array(repeating: 0x00, count: MapWidth+1), count: MapHeight+1)
        
        for index in 0...MapHeight
        {
            for j in 0...MapWidth
            {
                let str = StringMap[index]
                let inner = str.index(str.startIndex, offsetBy: j)
                
                if(("0" <= StringMap[index][inner])&&("9" >= StringMap[index][inner])){
                    // DPartials[index][j] = StringMap[index][inner] - "0"
                }
                else if(("A" <= StringMap[index][inner])&&("F" >= StringMap[index][inner])){
                    //DPartials[index][j] = StringMap[index][inner] - 'A' + 0x0A;
                    DPartials[index][j] = 0x0F
                }
                else {
                    
                }
            }
        }
    }
    ///Author: Dylon 10/28
    ///Converts the color code into a pixel struct that contains appropriate colors and opacity
    func SetMiniMapColors(colorCode: UInt32) -> pixel{
        var rPixel: pixel = pixel(alpha: 0, red: 0, green: 0, blue: 0)
        rPixel.red   = UInt8(((colorCode | 0xFF000000)>>16) & 0xFF)
        rPixel.green = UInt8(((colorCode | 0xFF000000)>>8) & 0xFF)
        rPixel.blue  = UInt8(((colorCode | 0xFF000000))&0xFF)
        rPixel.alpha = UInt8(((colorCode | 0xFF000000)>>24)&0xFF)
        return rPixel
    }
    
    /// Create a 2D Terrain Map of tile indices
    /// The value at a row and column is the index of the tile in the tileset
    func RenderTerrain(){ // DTerrainMap -> DMap
        DMap = Array(repeating: Array(repeating: ETileType.None, count: 0), count: DTerrainMap.count + 1)
        DMapIndices = Array(repeating: Array(repeating: 0, count: 0), count: DTerrainMap.count + 1)
        
        for YPos in 0...DMap.count-1{
            if((0 == YPos)||(DMap.count - 1 == YPos)){
                for _ in 0...DTerrainMap[0].count{
                    DMap[YPos].append(ETileType.Rock);
                    DMapIndices[YPos].append(0xF);
                }
            }
            else{
                for XPos in 0...DTerrainMap[YPos-1].count{
                    if((0 == XPos)||(DTerrainMap[YPos-1].count == XPos)){
                        DMap[YPos].append(ETileType.Rock);
                        DMapIndices[YPos].append(0xF);
                    }
                    else{
                        var Type:ETileType = ETileType.None
                        var Index:Int = 0
                        CalculateTileTypeAndIndex(x: XPos-1, y: YPos-1, type: &Type, index: &Index);
                        DMap[YPos].append(Type);
                        DMapIndices[YPos].append(Index);
                    }
                }
            }
        }
    }
    
    func TileType(x: Int, y: Int) -> ETileType{
        return DMap[y+1][x+1];
    }
    
    func TileTypeIndex(x: Int, y:Int) -> Int{
        return DMapIndices[y+1][x+1]
    }
}

