//
//  ChangeVC.swift
//  Warcraft2v1
//
//  Created by administrator on 10/28/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//
//CONSTANTS:
let TAG_MULTI = 2
let TAG_OPT = 3
let TAG_EXIT = 4
let TAG_SOUNDOP = 1
let TAG_NETOP = 2
let TAG_BACK = 3
let TAG_THREE = 1
let TAG_NOWAY = 2
let TAG_ONEWAY = 3
let TAG_NOWHERE = 4


import Foundation
import UIKit

func changeVC(change: String, view: UIViewController)->Void{
    
    let main = UIStoryboard(name: "Main", bundle: nil)
    let change = main.instantiateViewController(withIdentifier: change)
    view.present(change,animated: true, completion: nil)

    
}
