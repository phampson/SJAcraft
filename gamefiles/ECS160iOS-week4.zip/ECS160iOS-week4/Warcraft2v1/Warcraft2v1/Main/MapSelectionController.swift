//
//  MapSelectionController.swift
//  Warcraft2v1
//
//  Created by Patty Liu on 10/30/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//

import UIKit
import AVFoundation
import SpriteKit

class MapSelectionController: UIViewController {
    

    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "Background.png")!)
    }
   
    
    @IBAction func single(_ sender: UIButton)
    {
        playWav(file: "thunk", dir: "snd/misc")
        self.performSegue(withIdentifier: "toGame", sender: self)
        
    }
    
    @IBAction func ButtonsActions(_ sender: UIButton)
    {
        
        playWav(file: "thunk", dir: "snd/misc")
        
        switch sender.tag
        {
        case TAG_THREE:
            changeVC(change: "Game", view: self)
            print("One Way")
    
        case TAG_NOWAY:
            print("No way")
            
        case TAG_ONEWAY:
            print("One way")
            
        case TAG_NOWHERE:
            print("No where")
      
        default:
            break
        }
        
    }
    
}

