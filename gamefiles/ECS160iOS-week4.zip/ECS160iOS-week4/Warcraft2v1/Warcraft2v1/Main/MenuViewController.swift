//
//  MainViewController.swift
//  Warcraft2v1
//
//  Created by Stephen Wang on 10/7/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//


import UIKit
import AVFoundation
import SpriteKit


var startedMainMenu = false
class MenuViewController: UIViewController {
    
    //Audio variables
    var menuPlayer:AVAudioPlayer!
    
    override func viewDidLoad() {
        
        if (startedMainMenu == false)
        {
            playSound(file: "menu")
            startedMainMenu = true
        }
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "Background.png")!)
        // Do any additional setup after loading the view, typically from a nib.

    }
//
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }

    @IBAction func single(_ sender: UIButton)
    {
        playWav(file: "thunk", dir: "snd/misc")
        self.performSegue(withIdentifier: "toGame", sender: self)
        
    }
    
    
    /// -Authors: Andy Tran 10/12
    /// -Function" ButtonsActions
    /// -Description: Links button click to a specific action. Determines what button is which based on TAG
    ///TODO: Perform a seque on each button based on the tags
    @IBAction func ButtonsActions(_ sender: UIButton)
    {
        
        playWav(file: "thunk", dir: "snd/misc")
        
        switch sender.tag
        {
        case TAG_MULTI:
            print("Multiplayer")
            //code
        case TAG_OPT:
            print("Options")
            changeVC(change: "OptionVC", view: self)
            //code
        case TAG_EXIT:
            print("Exit")
            //code
        default:
            break
        }
        
    }
    
}

