//
//  OptionViewController.swift
//  Warcraft2v1
//
//  Created by administrator on 10/28/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//

import UIKit

class OptionViewController: UIViewController {

    
    @IBAction func optionButton(_ sender: UIButton) {
        
        playWav(file: "thunk", dir: "snd/misc")
        switch sender.tag
        {
        case TAG_SOUNDOP:
            print("Sound Options")
        //code
        case TAG_NETOP:
            print("Network Options")
            //code
        case TAG_BACK:
            print("Back")
            changeVC(change: "MenuVC", view: self)
        //code
        default:
            break
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "Background.png")!)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
