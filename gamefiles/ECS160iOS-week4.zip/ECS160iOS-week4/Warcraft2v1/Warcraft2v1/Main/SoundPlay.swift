//
//  SoundPlay.swift
//  Warcraft2v1
//
//  Created by administrator on 10/28/17.
//  Copyright © 2017 Stephen Wang. All rights reserved.
//

import Foundation
import AVFoundation

var wavPlayer:AVAudioPlayer!
var mp3Player:AVAudioPlayer!

/// -Authors: Andy Tran 10/28
/// -Function: playWav, playSound
/// -Description: Play wav or mp3 file without reptitive calling. Can be called globally
/// -Inputs: playWav: file name, directory , playSound: file name
func playWav(file:String, dir:String)-> Void {
    do{
        let wavPath = Bundle.main.path(forResource: file, ofType: "wav", inDirectory: dir)!
        let wavURL = URL(fileURLWithPath: wavPath)
        try wavPlayer = AVAudioPlayer(contentsOf: wavURL)
        wavPlayer.play()
    }catch{
        //error
    }
}

func playSound(file:String)-> Void {
    do{
        let soundPath = Bundle.main.path(forResource: file, ofType: "mp3", inDirectory: "snd/music")!
        let soundURL = URL(fileURLWithPath: soundPath)
        try mp3Player = AVAudioPlayer(contentsOf: soundURL)
        mp3Player.numberOfLoops = -1
        mp3Player.play()
        
    }catch{
        //error
    }
}

